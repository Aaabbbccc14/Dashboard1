# Wealth Distribution Dashboard

Sample WPF dashboard with chart and datagrid using LiveCharts.