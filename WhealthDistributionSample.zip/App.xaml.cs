using System.Windows;

namespace DashboardApp
{
    public partial class App : Application
    {
    }
}
